Open Charge Map 8.8.1 — Connector Type Icons

Extracted from:
assets/public/assets/images/icons/connectors/

Included formats:
- svg/: original SVG assets from the APK
- png_512/: rendered 512×512 PNG copies
- preview_all_connectors.png: contact sheet

Icons:
- CHAdeMO Type 4
- Type 1 CCS
- Type 1 J1772
- Type 2 CCS
- Type 2 socket
- Type 2 tethered
- Type 3c
- Schuko
- Tesla HPWC Model S
- Unknown

Original license file is included.
